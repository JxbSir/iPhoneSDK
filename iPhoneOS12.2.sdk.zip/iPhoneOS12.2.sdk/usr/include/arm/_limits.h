/*
 * Copyright (c) 2004-2007 Apple Inc. All rights reserved.
 */
#ifndef _ARM__LIMITS_H_
#define _ARM__LIMITS_H_

#define __DARWIN_CLK_TCK                100     /* ticks per second */

#endif  /* _ARM__LIMITS_H_ */
